DROP TABLE IF EXISTS `#__agentengine_agents`;
