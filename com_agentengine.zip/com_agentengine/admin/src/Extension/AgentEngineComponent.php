<?php
namespace Jules\Component\AgentEngine\Administrator\Extension;

defined('_JEXEC') or die;

use Joomla\CMS\Extension\MVCComponent;

class AgentEngineComponent extends MVCComponent
{
}
