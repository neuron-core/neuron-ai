<?php
defined('_JEXEC') or die;
?>
<div class="container">
  <h1>Hello World (Admin)</h1>
  <p><?php echo $this->greeting; ?></p>
  <p>You can now replace this with your own PHP/HTML.</p>
</div>
